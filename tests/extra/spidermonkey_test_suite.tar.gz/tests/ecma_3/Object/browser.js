var GLOBAL = 'Window';

function isObject(obj)
{
  return obj instanceof Object || obj == window;
}

